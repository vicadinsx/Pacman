To start the puppetmaster you can either use the run the puppetmaster with Visual Studio or open the folder "Binaries" and run PuppetMaster.exe.

Missing features:
InjectDelay